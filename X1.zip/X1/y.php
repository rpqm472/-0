<?php
include 'index.php';
var_dump(checkYahoo('cobra123@yahoo.com'));